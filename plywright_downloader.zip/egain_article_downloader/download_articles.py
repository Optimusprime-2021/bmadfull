#!/usr/bin/env python3
"""Excel → eGain article search → Word export, with durable resume/retry."""
from __future__ import annotations

import argparse
import asyncio
import csv
import json
import random
import sys
from pathlib import Path
from urllib.parse import urlsplit

from core import (Article, AuthenticationRequired, Checkpoint, ConfigurationError,
                  DownloadError, RunLock, atomic_move, normalize_id, read_input,
                  validate_word)


HERE = Path(__file__).resolve().parent


def load_config(path):
    try:
        config = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        raise ConfigurationError("Cannot read config JSON; check path and syntax") from exc
    required = {
        "base_url", "browser_channel", "search_mode", "navigation_timeout_ms",
        "element_timeout_ms", "download_timeout_ms", "max_attempts", "retry_base_seconds",
        "between_articles_seconds", "max_download_bytes", "allow_html_doc", "selectors"
    }
    if set(config) != required:
        raise ConfigurationError("Config must contain exactly the keys in the supplied config.json")
    url = urlsplit(config["base_url"])
    if url.scheme != "https" or not url.hostname or url.username or url.password or url.query or url.fragment:
        raise ConfigurationError("base_url must be an HTTPS KB base URL without credentials, query or fragment")
    config["base_url"] = config["base_url"].rstrip("/")
    if config["browser_channel"] not in ("chrome", "msedge", None):
        raise ConfigurationError("browser_channel must be chrome, msedge, or null for bundled Chromium")
    if config["search_mode"] not in ("ui", "direct"):
        raise ConfigurationError("search_mode must be ui or direct")
    for name in ("navigation_timeout_ms", "element_timeout_ms", "download_timeout_ms", "max_attempts", "max_download_bytes"):
        if type(config[name]) is not int or config[name] <= 0:
            raise ConfigurationError(f"{name} must be a positive integer")
    for name in ("retry_base_seconds", "between_articles_seconds"):
        if isinstance(config[name], bool) or not isinstance(config[name], (int, float)) or not 0 <= config[name] <= 3600:
            raise ConfigurationError(f"{name} must be a number between 0 and 3600")
    if type(config["allow_html_doc"]) is not bool:
        raise ConfigurationError("allow_html_doc must be true or false")
    selectors = {"frame_css", "search_input_css", "search_submit_css", "result_link_css",
                 "result_item_css", "article_heading_css", "article_id_css", "word_export_css", "session_expired_css"}
    if not isinstance(config["selectors"], dict) or set(config["selectors"]) != selectors:
        raise ConfigurationError("selectors must contain the keys shown in the supplied config.json")
    for key, val in config["selectors"].items():
        if val is not None and (not isinstance(val, str) or not val.strip()):
            raise ConfigurationError(f"Selector {key} must be a nonempty CSS string or null")
    for key in ("result_link_css", "article_heading_css"):
        if config["selectors"][key] is None:
            raise ConfigurationError(f"Selector {key} is required")
    return config


def input_errors(output, errors):
    temp = Path(output) / "input_errors.csv.tmp"
    with temp.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["row", "value", "error"])
        writer.writeheader()
        for row in errors:
            writer.writerow({k: ("'"+v if isinstance(v, str) and v.startswith(("=", "+", "-", "@")) else v)
                             for k, v in row.items()})
    atomic_move(temp, Path(output) / "input_errors.csv")


async def process_articles(articles, checkpoint, browser, config, *, sleep=asyncio.sleep):
    """Run serially. File/SQLite commit errors abort; journal recovery handles restart."""
    stop_code = 0
    for index, article in enumerate(articles, 1):
        if checkpoint.recover_and_verify(article.article_id):
            print(f"[{index}/{len(articles)}] {article.article_id}: already downloaded; checksum verified")
            continue
        for attempt in range(1, config["max_attempts"] + 1):
            attempt_id = checkpoint.begin(article.article_id)
            stage = "START"
            exported = None
            def set_stage(value):
                nonlocal stage
                stage = value
                checkpoint.stage(article.article_id, value)
            print(f"[{index}/{len(articles)}] {article.article_id}: attempt {attempt}/{config['max_attempts']}")
            try:
                exported = await browser.download(article, set_stage)
                set_stage("VALIDATE_FILE")
                extension, validation = validate_word(
                    exported.temp_path, exported.filename, article.article_id, exported.title,
                    max_bytes=config["max_download_bytes"], allow_html_doc=config["allow_html_doc"])
                # Write a journal entry BEFORE rename. Never downgrade STAGED after a commit failure.
                checkpoint.prepare_commit(
                    article.article_id, exported.temp_path, extension,
                    article_url=exported.url, page_title=exported.title,
                    original_filename=exported.filename, validation=validation)
                final = checkpoint.finish_commit(article.article_id, attempt_id)
                print(f"  Saved {final.name}")
                break
            except OSError:
                # Disk full/permission errors are not fixed by repeatedly downloading.
                raise
            except Exception as raw:
                if checkpoint.get(article.article_id)["state"] == "STAGED":
                    raise  # Keep the durable journal available for next-run recovery.
                error = raw if isinstance(raw, DownloadError) else DownloadError(
                    f"Browser operation failed at {stage} ({type(raw).__name__}); inspect selectors/session")
                checkpoint.fail(article.article_id, attempt_id, error)
                if exported and exported.temp_path.exists():
                    exported.temp_path.unlink()
                print(f"  {error.code}: {error}")
                if isinstance(error, AuthenticationRequired):
                    stop_code = 3
                    break
                await browser.diagnostic(article.article_id, checkpoint.get(article.article_id)["attempts"])
                if not error.retryable or attempt == config["max_attempts"]:
                    break
                delay = min(60, config["retry_base_seconds"] * (2 ** (attempt-1)))
                if delay:
                    await sleep(delay + random.uniform(0, min(1, delay / 4)))
            finally:
                await browser.reset()
        if stop_code:
            break
        if index < len(articles) and config["between_articles_seconds"]:
            await sleep(config["between_articles_seconds"])
    if stop_code:
        return stop_code
    return 0 if all(checkpoint.get(a.article_id)["state"] == "SUCCESS" for a in articles) else 2


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    def common(command, browser=False):
        command.add_argument("--config", default=str(HERE / "config.json"))
        command.add_argument("--output", default=str(HERE / "output"))
        if browser:
            command.add_argument("--headless", action="store_true", help="Requires --non-interactive and a valid existing session")
            command.add_argument("--non-interactive", action="store_true", help="Reuse existing session without waiting for manual SSO")
    def spreadsheet(command):
        command.add_argument("--excel", required=True, help=".xlsx, .xlsm or UTF-8 CSV path")
        command.add_argument("--sheet", help="Default: active Excel sheet")
        command.add_argument("--id-column", default="Article #")
        command.add_argument("--title-column", default="Document Name")
        command.add_argument("--header-row", type=int, default=1, help="1-based header row number")
    plan = sub.add_parser("plan", help="Validate spreadsheet and display counts; no browser")
    spreadsheet(plan)
    run = sub.add_parser("run", help="Download/resume articles; successful files are verified and skipped")
    spreadsheet(run); common(run, True)
    run.add_argument("--limit", type=int, help="Process at most this many incomplete articles")
    run.add_argument("--only-failed", action="store_true", help="Select FAILED/AUTH_REQUIRED only; normal run also processes PENDING")
    inspect = sub.add_parser("inspect", help="Inspect real selectors; does not click Word export")
    common(inspect, True)
    inspect.add_argument("--article-id", help="Optional article to inspect, e.g. ID-45255")
    inspect.add_argument("--pause", action="store_true", help="Open Playwright Inspector (headed only)")
    status = sub.add_parser("status", help="Show checkpoint counts without launching a browser")
    common(status)
    return p


def get_input(args):
    if args.header_row < 1:
        raise ConfigurationError("--header-row must be at least 1")
    articles, errors, duplicates = read_input(
        args.excel, sheet=args.sheet, id_column=args.id_column,
        title_column=args.title_column, header_row=args.header_row)
    print(f"Input: {len(articles)} unique valid IDs; {duplicates} duplicate rows; {len(errors)} invalid rows")
    return articles, errors


async def run(args, config):
    from browser_flow import BrowserFlow
    articles, errors = get_input(args)
    output = Path(args.output).resolve()
    if args.limit is not None and args.limit < 1:
        raise ConfigurationError("--limit must be at least 1")
    with RunLock(output):
        checkpoint = Checkpoint(output, config["base_url"])
        try:
            checkpoint.import_articles(articles)
            input_errors(output, errors)
            eligible = []
            completed = 0
            for article in articles:
                if checkpoint.recover_and_verify(article.article_id):
                    completed += 1
                    continue
                if not args.only_failed or checkpoint.get(article.article_id)["state"] in {"FAILED", "AUTH_REQUIRED"}:
                    eligible.append(article)
            selected = eligible[:args.limit] if args.limit else eligible
            print(f"Resume: {completed} verified files; {len(selected)} articles selected for this invocation")
            if not articles:
                print("No valid article IDs to download.")
                return 2
            if not selected:
                return 2 if errors or completed != len(articles) else 0
            try:
                async with BrowserFlow(config, output, headless=args.headless,
                                       interactive=not args.non_interactive) as browser:
                    await browser.login()
                    code = await process_articles(selected, checkpoint, browser, config)
            except AuthenticationRequired:
                print("SSO is required. Rerun without --headless/--non-interactive, sign in and resume.")
                return 3
            return code if code else (2 if errors else 0)
        finally:
            try:
                print("Report:", json.dumps(checkpoint.report([a.article_id for a in articles])))
                print(f"Files and reports: {output}")
            finally:
                checkpoint.close()


async def inspect(args, config):
    from browser_flow import BrowserFlow
    if args.pause and args.headless:
        raise ConfigurationError("--pause requires a headed browser")
    article_id = normalize_id(args.article_id) if args.article_id else None
    output = Path(args.output).resolve()
    with RunLock(output):
        # Keep a profile bound to its KB site, just as the run command does.
        checkpoint = Checkpoint(output, config["base_url"])
        try:
            async with BrowserFlow(config, output, headless=args.headless,
                                   interactive=not args.non_interactive) as browser:
                await browser.login(validate_search=False)
                await browser.inspect(article_id, pause=args.pause)
        finally:
            checkpoint.close()
    return 0


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.command == "plan":
            articles, errors = get_input(args)
            for article in articles[:10]:
                print(f"  {article.article_id}  {article.title}")
            for error in errors[:20]:
                print(f"  Invalid row {error['row']}: {error['error']}")
            return 2 if errors or not articles else 0
        config = load_config(args.config)
        if getattr(args, "headless", False) and not args.non_interactive:
            raise ConfigurationError("--headless requires --non-interactive and an existing authenticated profile")
        if args.command == "run":
            return asyncio.run(run(args, config))
        if args.command == "inspect":
            return asyncio.run(inspect(args, config))
        output = Path(args.output).resolve()
        if not (output / "checkpoint.sqlite3").exists():
            raise ConfigurationError("No checkpoint database found in this output folder")
        with RunLock(output):
            checkpoint = Checkpoint(output, config["base_url"])
            try:
                counts = {r[0]: r[1] for r in checkpoint.db.execute("SELECT state,COUNT(*) FROM articles GROUP BY state")}
                print(json.dumps(counts, indent=2))
                print("Counts cover all IDs seen in this output folder. run rechecks file checksums.")
            finally:
                checkpoint.close()
        return 0
    except KeyboardInterrupt:
        print("\nStopped. Rerun the same command to resume from the checkpoint.")
        return 130
    except AuthenticationRequired:
        print("Sign-in required. Run headed, complete normal SSO/MFA, then resume.")
        return 3
    except (ConfigurationError, ValueError, FileNotFoundError) as exc:
        print(f"Configuration/input error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        # Do not echo raw browser call logs containing query parameters or SSO tokens.
        print(f"Run stopped ({type(exc).__name__}). Check local file permissions, disk space, browser setup and config. "
              "Checkpoint is preserved; rerun to resume.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
