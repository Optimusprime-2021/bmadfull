# Verification record

Verified on 2026-09-18 in the build environment.

| Check | Result |
|---|---|
| Python syntax compilation | Passed for all source and test files |
| Offline test suite | 31 tests passed |
| Sample XLSX input | 20 unique valid IDs, 0 duplicate rows, 0 invalid rows |
| Sample workbook visual review | All rows, headings and source note are readable |

The offline suite exercises real SQLite transactions, temporary files, checksum validation, CSV parsing and result-selection logic. It simulates browser successes and failures at the network boundary to verify retry, resume, authentication stops and continued processing after a failed article.

Recovery was tested after interruptions before the final file rename and after the rename but before the success record. Successful files were also deleted or changed to verify that a later run queues them again.

Live eGain navigation, corporate SSO, Windows browser launch and the real Word export have not been tested. Use the one-article command in README.md to verify these on the corporate computer before the full run.
