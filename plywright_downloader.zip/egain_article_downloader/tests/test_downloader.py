"""Offline tests: real files + SQLite; fake browser at the network boundary."""
import asyncio
import csv
import io
import json
import tempfile
import unittest
import zipfile
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

from browser_flow import Export, choose_result, clean_url
from core import (Article, AuthenticationRequired, Checkpoint, ConfigurationError,
                  DownloadError, IdentityError, InvalidDownload, RunLock, atomic_move,
                  normalize_id, parse_rows, read_input, validate_word, within)
from download_articles import load_config, process_articles


SITE = "https://kb.example.test/ccb/kb/regops"


def docx(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr('[Content_Types].xml', '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')
        z.writestr('word/document.xml', '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>ID-45255 Test article</w:t></w:r></w:p></w:body></w:document>')
    return path


class InputTests(unittest.TestCase):
    def test_normalization_and_invalid_cells(self):
        for value in ('ID-45255', ' id 45255 ', '45255', 45255, 45255.0, 'ID–45255'):
            self.assertEqual(normalize_id(value), 'ID-45255')
        self.assertEqual(normalize_id('ID-0042'), 'ID-0042')
        for value in (None, True, 42.5, float('nan'), '=A2', '../../42', 'ID-ABC'):
            with self.assertRaises(ValueError):
                normalize_id(value)

    def test_dedup_retains_rows_and_reports_bad_ids(self):
        rows = [['Article #','Document Name'], ['ID-45255','Title'],
                [45255,'Title duplicate'], [None,None], ['bad','Bad title'], ['ID-45257','Second']]
        articles, errors, dup = parse_rows(rows)
        self.assertEqual([a.article_id for a in articles], ['ID-45255', 'ID-45257'])
        self.assertEqual(articles[0].rows, [2,3])
        self.assertEqual(dup, 1)
        self.assertEqual(errors[0]['row'], 5)

    def test_header_row_and_missing_header(self):
        articles, _, _ = parse_rows([['Intro'],['Article #'],['ID-1']], header_row=2)
        self.assertEqual(articles[0].article_id, 'ID-1')
        with self.assertRaises(ConfigurationError):
            parse_rows([['Wrong']])
        with self.assertRaises(ConfigurationError):
            parse_rows([['Article #','Article #']])

    def test_csv_input(self):
        with tempfile.TemporaryDirectory() as d:
            file = Path(d) / 'input.csv'
            file.write_text('Article #,Document Name\nID-45255,Title\n', encoding='utf-8-sig')
            articles, errors, duplicates = read_input(file)
            self.assertEqual((len(articles),len(errors),duplicates), (1,0,0))


class SelectionTests(unittest.TestCase):
    def test_exact_id_preferred_and_no_padded_url_guess(self):
        article = Article('ID-45255', 'A title')
        candidates = [
            {'href': SITE+'/content/internal-one/Other', 'text':'Other', 'card_text':'ID-99999'},
            {'href': SITE+'/content/internal-two/A', 'text':'A title', 'card_text':'ID-45255'},
        ]
        self.assertEqual(choose_result(candidates, article, SITE), SITE+'/content/internal-two/A')

    def test_duplicates_same_url_are_one_result(self):
        item = {'href':SITE+'/content/a/title', 'text':'Title','card_text':'ID-45255'}
        self.assertEqual(choose_result([item,item], Article('ID-45255'), SITE), item['href'])

    def test_ambiguous_results_fail_instead_of_first_link(self):
        items=[{'href':SITE+'/content/'+x, 'text':x, 'card_text':''} for x in ('a','b')]
        with self.assertRaises(IdentityError):
            choose_result(items, Article('ID-45255'), SITE)

    def test_other_site_and_non_article_links_are_ignored(self):
        items=[{'href':'https://other.example/content/x', 'text':'Title'},
               {'href':SITE+'/search?q=ID-45255', 'text':'Title'}]
        self.assertIsNone(choose_result(items, Article('ID-45255'), SITE))

    def test_provenance_url_excludes_query_and_fragment(self):
        self.assertEqual(clean_url(SITE+'/content/a?token=secret#x'), SITE+'/content/a')


class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
    def tearDown(self):
        self.tmp.cleanup()
    def test_valid_docx(self):
        ext, kind = validate_word(docx(self.root/'f.part'), 'Article.docx', 'ID-45255','Test article')
        self.assertEqual(ext,'.docx'); self.assertEqual(kind,'DOCX_CONTAINER_VALIDATED')
    def test_login_html_disguised_as_docx_is_rejected(self):
        path=self.root/'f.part'; path.write_text('<html><body>Please sign in to continue</body></html>')
        with self.assertRaises(InvalidDownload):
            validate_word(path,'Article.docx','ID-45255','Test article')
    def test_html_doc_requires_identity_and_no_password_form(self):
        path=self.root/'f.part'
        path.write_text('<html><body>ID-45255 Test article export content</body></html>')
        self.assertEqual(validate_word(path,'Article.doc','ID-45255','Test article')[0],'.doc')
        path.write_text('<html><body>Sign in <input type="password"> ID-45255</body></html>')
        with self.assertRaises(InvalidDownload):
            validate_word(path,'Article.doc','ID-45255','Test article')
        path.write_text('<html><body>Unrelated article with a different title</body></html>')
        with self.assertRaises(InvalidDownload):
            validate_word(path,'Article.doc','ID-45255','Test article')
    def test_unsupported_and_oversize_downloads(self):
        path=docx(self.root/'f.part')
        with self.assertRaises(InvalidDownload):
            validate_word(path,'Article.pdf','ID-45255','Test article')
        with self.assertRaises(InvalidDownload):
            validate_word(path,'Article.docx','ID-45255','Test article',max_bytes=32)
    def test_legacy_doc_and_rtf_keep_true_extensions(self):
        path=self.root/'f.part'; path.write_bytes(bytes.fromhex('D0CF11E0A1B11AE1')+b'0'*100)
        self.assertEqual(validate_word(path,'Article.doc','ID-1','Title')[0],'.doc')
        path.write_bytes(b'{\\rtf1 '+b'content '*20+b'}')
        self.assertEqual(validate_word(path,'Article.rtf','ID-1','Title')[0],'.rtf')


class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.cp=Checkpoint(self.root,SITE); self.article=Article('ID-45255','Title',rows=[2])
        self.cp.import_articles([self.article])
    def tearDown(self):
        self.cp.close(); self.tmp.cleanup()
    def stage(self):
        attempt=self.cp.begin(self.article.article_id)
        temp=docx(self.root/'staging'/'export.part')
        final=self.cp.prepare_commit(self.article.article_id,temp,'.docx',
            article_url=SITE+'/content/a',page_title='Title',original_filename='a.docx',validation='DOCX_CONTAINER_VALIDATED')
        return attempt,temp,final
    def reopen(self):
        self.cp.close(); self.cp=Checkpoint(self.root,SITE)
    def test_resume_after_crash_before_rename(self):
        _, temp, final=self.stage(); self.reopen()
        self.assertTrue(self.cp.recover_and_verify(self.article.article_id))
        self.assertTrue(final.exists()); self.assertFalse(temp.exists())
        self.assertEqual(self.cp.get(self.article.article_id)['attempts'],1)
    def test_resume_after_crash_after_rename(self):
        _, temp, final=self.stage(); atomic_move(temp,final); self.reopen()
        self.assertTrue(self.cp.recover_and_verify(self.article.article_id))
        self.assertEqual(self.cp.get(self.article.article_id)['state'],'SUCCESS')
    def test_success_is_skipped_only_when_hash_matches(self):
        attempt, _, final=self.stage(); self.cp.finish_commit(self.article.article_id,attempt)
        self.assertTrue(self.cp.recover_and_verify(self.article.article_id))
        # Same size, changed bytes: checksum must catch corruption.
        data=final.read_bytes(); final.write_bytes(b'X'+data[1:])
        self.assertFalse(self.cp.recover_and_verify(self.article.article_id))
        self.assertEqual(self.cp.get(self.article.article_id)['state'],'PENDING')
    def test_missing_successful_file_is_requeued(self):
        attempt, _, final=self.stage(); self.cp.finish_commit(self.article.article_id,attempt); final.unlink()
        self.assertFalse(self.cp.recover_and_verify(self.article.article_id))
        self.assertEqual(self.cp.get(self.article.article_id)['error_code'],'LOCAL_FILE_MISSING_OR_CHANGED')
    def test_interrupted_attempt_resumes_and_keeps_history(self):
        self.cp.begin(self.article.article_id); self.reopen()
        self.assertFalse(self.cp.recover_and_verify(self.article.article_id))
        outcome=self.cp.db.execute('SELECT outcome FROM attempts').fetchone()[0]
        self.assertEqual(outcome,'INTERRUPTED')
    def test_missing_staged_file_requeues(self):
        _, temp, _=self.stage(); temp.unlink(); self.reopen()
        self.assertFalse(self.cp.recover_and_verify(self.article.article_id))
        self.assertEqual(self.cp.get(self.article.article_id)['state'],'PENDING')
    def test_output_folder_is_bound_to_site(self):
        with self.assertRaises(ConfigurationError):
            Checkpoint(self.root,'https://other.example')
    def test_report_is_current_input_and_escapes_excel_formula(self):
        self.cp.import_articles([Article('ID-42','=HYPERLINK("bad")',rows=[3])])
        counts=self.cp.report(['ID-42'])
        self.assertEqual(counts,{'PENDING':1})
        with (self.root/'download_report.csv').open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),1); self.assertTrue(rows[0]['title'].startswith("'="))
    def test_lock_prevents_concurrent_run_and_releases(self):
        with RunLock(self.root):
            with self.assertRaises(ConfigurationError):
                with RunLock(self.root): pass
        with RunLock(self.root): pass
    def test_checkpoint_paths_cannot_escape_output(self):
        with self.assertRaises(ConfigurationError): within(self.root,'../other.docx')


class FakeBrowser:
    def __init__(self, root, errors=None):
        self.root=root; self.errors=errors or {}; self.calls=[]; self.diagnostics=[]; self.resets=0
    async def download(self, article, stage):
        self.calls.append(article.article_id); stage('WORD_EXPORT')
        queue=self.errors.get(article.article_id,[])
        if queue:
            error=queue.pop(0)
            if error: raise error
        return Export(docx(self.root/'staging'/f'{article.article_id}.part'), 'article.docx',article.title,SITE+'/content/a')
    async def diagnostic(self, article_id, attempt): self.diagnostics.append(article_id)
    async def reset(self): self.resets+=1


class RunnerTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.cp=Checkpoint(self.root,SITE)
        self.articles=[Article('ID-45255','First'),Article('ID-45257','Second')]
        self.cp.import_articles(self.articles)
        self.config=load_config(Path(__file__).resolve().parents[1]/'config.json')
        self.config.update(retry_base_seconds=0,between_articles_seconds=0)
    def tearDown(self):
        self.cp.close(); self.tmp.cleanup()
    async def run_fake(self, fake):
        with redirect_stdout(io.StringIO()):
            return await process_articles(self.articles,self.cp,fake,self.config)
    async def test_transient_failure_retries_then_saves_all(self):
        fake=FakeBrowser(self.root,{'ID-45255':[DownloadError('temporary'),None]})
        self.assertEqual(await self.run_fake(fake),0)
        self.assertEqual(fake.calls,['ID-45255','ID-45255','ID-45257'])
        self.assertEqual(self.cp.get('ID-45255')['attempts'],2)
    async def test_failed_article_does_not_prevent_later_download(self):
        fake=FakeBrowser(self.root,{'ID-45255':[DownloadError('temporary') for _ in range(3)]})
        self.assertEqual(await self.run_fake(fake),2)
        self.assertEqual(self.cp.get('ID-45255')['state'],'FAILED')
        self.assertEqual(self.cp.get('ID-45257')['state'],'SUCCESS')
    async def test_ssos_expiry_stops_without_touching_next_article(self):
        fake=FakeBrowser(self.root,{'ID-45255':[AuthenticationRequired('login needed')]})
        self.assertEqual(await self.run_fake(fake),3)
        self.assertEqual(fake.calls,['ID-45255'])
        self.assertEqual(self.cp.get('ID-45255')['state'],'AUTH_REQUIRED')
        self.assertEqual(self.cp.get('ID-45257')['state'],'PENDING')
        self.assertEqual(fake.diagnostics,[])
    async def test_rerun_skips_verified_completed_articles(self):
        self.assertEqual(await self.run_fake(FakeBrowser(self.root)),0)
        fake=FakeBrowser(self.root)
        self.assertEqual(await self.run_fake(fake),0)
        self.assertEqual(fake.calls,[])
    async def test_identity_failure_is_not_retried(self):
        fake=FakeBrowser(self.root,{'ID-45255':[IdentityError('wrong article')]})
        self.assertEqual(await self.run_fake(fake),2)
        self.assertEqual(fake.calls,['ID-45255','ID-45257'])
    async def test_browser_exception_does_not_persist_token(self):
        fake=FakeBrowser(self.root,{'ID-45255':[RuntimeError('https://sso.example?token=secret') for _ in range(3)]})
        self.assertEqual(await self.run_fake(fake),2)
        row=self.cp.get('ID-45255')
        self.assertNotIn('secret',row['error_message']); self.assertIn('WORD_EXPORT',row['error_message'])
    async def test_commit_error_keeps_staged_journal(self):
        fake=FakeBrowser(self.root)
        with patch('core.atomic_move',side_effect=OSError('disk error')):
            with self.assertRaises(OSError): await self.run_fake(fake)
        self.assertEqual(self.cp.get('ID-45255')['state'],'STAGED')
        self.assertTrue(self.cp.recover_and_verify('ID-45255'))


if __name__ == '__main__':
    unittest.main()
