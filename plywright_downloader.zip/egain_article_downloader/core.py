"""Input parsing, single-run locking, durable checkpoints and file validation."""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import re
import sqlite3
import unicodedata
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class DownloadError(Exception):
    code = "DOWNLOAD_ERROR"
    retryable = True


class ConfigurationError(DownloadError):
    code, retryable = "CONFIGURATION_ERROR", False


class AuthenticationRequired(DownloadError):
    code, retryable = "AUTH_REQUIRED", False


class IdentityError(DownloadError):
    code, retryable = "ARTICLE_IDENTITY_ERROR", False


class SelectorError(DownloadError):
    code, retryable = "SELECTOR_ERROR", False


class ArticleNotFound(DownloadError):
    code = "NOT_FOUND"


class InvalidDownload(DownloadError):
    code = "INVALID_DOWNLOAD"


class AccessBlocked(DownloadError):
    code, retryable = "ACCESS_BLOCKED", False


@dataclass
class Article:
    article_id: str
    title: str = ""
    area: str = ""
    rows: list[int] = field(default_factory=list)


def normalize_id(value):
    if isinstance(value, bool) or value is None:
        raise ValueError("Article ID is missing or invalid")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Article ID must contain whole-number digits")
        value = int(value)
    text = unicodedata.normalize("NFKC", str(value)).strip()
    match = re.fullmatch(r"(?:ID\s*[-–—]?\s*)?(\d{1,20})", text, re.I)
    if not match:
        raise ValueError("Expected an ID such as ID-45255 or 45255; formulas are not supported")
    return "ID-" + match.group(1)


def header_key(value):
    return " ".join(str(value or "").strip().casefold().split())


def parse_rows(rows, id_column="Article #", title_column="Document Name", header_row=1):
    iterator = iter(rows)
    for _ in range(header_row - 1):
        next(iterator, None)
    header = next(iterator, None)
    if header is None:
        raise ConfigurationError("The input has no header row")
    names = [header_key(x) for x in header]
    key = header_key(id_column)
    if names.count(key) != 1:
        raise ConfigurationError(f"Expected exactly one '{id_column}' column; found headers: {list(header)}")
    id_index = names.index(key)
    title_index = names.index(header_key(title_column)) if header_key(title_column) in names else None
    area_index = names.index("owning area") if "owning area" in names else None
    articles, errors, duplicates = {}, [], 0
    for row_number, row in enumerate(iterator, header_row + 1):
        if all(v is None or str(v).strip() == "" for v in row):
            continue
        at = lambda i: row[i] if i is not None and i < len(row) else None
        try:
            article_id = normalize_id(at(id_index))
        except ValueError as exc:
            errors.append({"row": row_number, "value": str(at(id_index) or ""), "error": str(exc)})
            continue
        title = str(at(title_index) or "").strip()
        if article_id in articles:
            duplicates += 1
            articles[article_id].rows.append(row_number)
            if not articles[article_id].title:
                articles[article_id].title = title
        else:
            articles[article_id] = Article(article_id, title, str(at(area_index) or "").strip(), [row_number])
    return list(articles.values()), errors, duplicates


def read_input(path, sheet=None, **kwargs):
    path = Path(path)
    if path.suffix.lower() == ".csv":
        with path.open(newline="", encoding="utf-8-sig") as f:
            return parse_rows(csv.reader(f), **kwargs)
    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ConfigurationError("Use .xlsx, .xlsm or UTF-8 .csv; save legacy .xls as .xlsx first")
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise ConfigurationError("Install requirements.txt to read Excel workbooks") from exc
    book = load_workbook(path, read_only=True, data_only=False, keep_links=False)
    try:
        if sheet and sheet not in book.sheetnames:
            raise ConfigurationError(f"Sheet '{sheet}' not found; available sheets: {book.sheetnames}")
        ws = book[sheet] if sheet else book.active
        return parse_rows(ws.iter_rows(values_only=True), **kwargs)
    finally:
        book.close()


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def within(root, relative):
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if path == root or not path.is_relative_to(root):
        raise ConfigurationError("Checkpoint file path escapes the output directory")
    return path


class RunLock:
    """OS-held advisory lock, automatically released when a process exits."""
    def __init__(self, root):
        self.path = Path(root) / "run.lock"
        self.file = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open("a+b")
        if self.path.stat().st_size == 0:
            self.file.write(b"0"); self.file.flush()
        self.file.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.file.close()
            raise ConfigurationError("Another process is using this output folder/profile") from exc
        return self

    def __exit__(self, *_):
        if self.file:
            if os.name == "nt":
                import msvcrt
                self.file.seek(0); msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
            self.file.close()


def sync_file(path):
    with Path(path).open("rb+") as f:
        os.fsync(f.fileno())


def atomic_move(source, target):
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    os.replace(source, target)
    if os.name != "nt":
        descriptor = os.open(target.parent, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


class Checkpoint:
    def __init__(self, root, site):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.root / "checkpoint.sqlite3")
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS articles(
          article_id TEXT PRIMARY KEY, title TEXT, area TEXT, source_rows TEXT,
          state TEXT NOT NULL DEFAULT 'PENDING', stage TEXT, attempts INTEGER NOT NULL DEFAULT 0,
          file_path TEXT, staged_path TEXT, digest TEXT, byte_count INTEGER,
          article_url TEXT, page_title TEXT, original_filename TEXT, validation TEXT,
          error_code TEXT, error_message TEXT, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS attempts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, article_id TEXT NOT NULL,
          started_at TEXT NOT NULL, finished_at TEXT, outcome TEXT, error_code TEXT, error_message TEXT);
        """)
        old = self.db.execute("SELECT value FROM metadata WHERE key='site'").fetchone()
        if old and old[0] != site:
            self.db.close()
            raise ConfigurationError("Output folder belongs to a different KB site; choose another --output")
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO metadata VALUES('site',?)", (site,))

    def close(self):
        self.db.close()

    def import_articles(self, articles):
        with self.db:
            for a in articles:
                self.db.execute("""INSERT INTO articles(article_id,title,area,source_rows,updated_at)
                VALUES(?,?,?,?,?) ON CONFLICT(article_id) DO UPDATE SET
                title=excluded.title,area=excluded.area,source_rows=excluded.source_rows""",
                (a.article_id, a.title, a.area, json.dumps(a.rows), utcnow()))

    def get(self, article_id):
        return self.db.execute("SELECT * FROM articles WHERE article_id=?", (article_id,)).fetchone()

    def stage(self, article_id, stage):
        with self.db:
            self.db.execute("UPDATE articles SET stage=?,updated_at=? WHERE article_id=?", (stage, utcnow(), article_id))

    def begin(self, article_id):
        with self.db:
            self.db.execute("UPDATE articles SET state='IN_PROGRESS',attempts=attempts+1,error_code=NULL,error_message=NULL,updated_at=? WHERE article_id=?", (utcnow(), article_id))
            return self.db.execute("INSERT INTO attempts(article_id,started_at) VALUES(?,?)", (article_id, utcnow())).lastrowid

    def fail(self, article_id, attempt_id, error):
        code = getattr(error, "code", "TRANSIENT_BROWSER_ERROR")
        state = "AUTH_REQUIRED" if code == "AUTH_REQUIRED" else "FAILED"
        # Browser exceptions must be sanitized by the caller before reaching this method.
        message = str(error).splitlines()[0][:400]
        with self.db:
            self.db.execute("UPDATE articles SET state=?,error_code=?,error_message=?,updated_at=? WHERE article_id=?", (state, code, message, utcnow(), article_id))
            self.db.execute("UPDATE attempts SET finished_at=?,outcome='FAILED',error_code=?,error_message=? WHERE id=?", (utcnow(), code, message, attempt_id))

    def prepare_commit(self, article_id, temp, extension, *, article_url, page_title, original_filename, validation):
        temp = Path(temp).resolve()
        relative_temp = str(temp.relative_to(self.root))
        within(self.root, relative_temp)
        final = f"articles/{article_id}{extension}"
        sync_file(temp)
        digest, size = sha256(temp), temp.stat().st_size
        with self.db:
            self.db.execute("""UPDATE articles SET state='STAGED',stage='COMMIT_DOWNLOAD',
             file_path=?,staged_path=?,digest=?,byte_count=?,article_url=?,page_title=?,
             original_filename=?,validation=?,updated_at=? WHERE article_id=?""",
             (final, relative_temp, digest, size, article_url, page_title, original_filename,
              validation, utcnow(), article_id))
        return within(self.root, final)

    def finish_commit(self, article_id, attempt_id=None):
        row = self.get(article_id)
        final, temp = within(self.root, row['file_path']), within(self.root, row['staged_path'])
        valid = lambda p: p.is_file() and p.stat().st_size == row['byte_count'] and sha256(p) == row['digest']
        if not valid(final):
            if not valid(temp):
                raise InvalidDownload("Staged download is missing or has changed")
            atomic_move(temp, final)
        with self.db:
            self.db.execute("UPDATE articles SET state='SUCCESS',stage='COMPLETE',staged_path=NULL,error_code=NULL,error_message=NULL,updated_at=? WHERE article_id=?", (utcnow(), article_id))
            if attempt_id:
                self.db.execute("UPDATE attempts SET outcome='SUCCESS',finished_at=? WHERE id=?", (utcnow(), attempt_id))
            else:
                self.db.execute("UPDATE attempts SET outcome='RECOVERED',finished_at=? WHERE article_id=? AND finished_at IS NULL", (utcnow(), article_id))
        if temp != final and temp.exists():
            temp.unlink()
        return final

    def recover_and_verify(self, article_id):
        row = self.get(article_id)
        if row['state'] == 'STAGED':
            try:
                self.finish_commit(article_id)
            except InvalidDownload:
                with self.db:
                    self.db.execute("UPDATE articles SET state='PENDING',error_code='STAGED_FILE_MISSING' WHERE article_id=?", (article_id,))
                    self.db.execute("UPDATE attempts SET outcome='INTERRUPTED',finished_at=? WHERE article_id=? AND finished_at IS NULL", (utcnow(), article_id))
            row = self.get(article_id)
        if row['state'] == 'SUCCESS':
            path = within(self.root, row['file_path'])
            if path.is_file() and path.stat().st_size == row['byte_count'] and sha256(path) == row['digest']:
                return True
            with self.db:
                self.db.execute("UPDATE articles SET state='PENDING',error_code='LOCAL_FILE_MISSING_OR_CHANGED' WHERE article_id=?", (article_id,))
        elif row['state'] == 'IN_PROGRESS':
            with self.db:
                self.db.execute("UPDATE articles SET state='PENDING',error_code='INTERRUPTED' WHERE article_id=?", (article_id,))
                self.db.execute("UPDATE attempts SET outcome='INTERRUPTED',finished_at=? WHERE article_id=? AND finished_at IS NULL", (utcnow(), article_id))
        return False

    def report(self, article_ids):
        columns = ['article_id','title','source_rows','state','stage','attempts','file_path','digest','byte_count','article_url','validation','error_code','error_message','updated_at']
        rows = [dict(self.get(a)) for a in article_ids]
        for name, subset in [('download_report.csv', rows), ('failed_articles.csv', [r for r in rows if r['state'] != 'SUCCESS'])]:
            temp = self.root / (name + '.tmp')
            with temp.open('w', newline='', encoding='utf-8-sig') as f:
                w = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore'); w.writeheader()
                for row in subset:
                    # Reports are opened in Excel; keep source text from becoming formulas.
                    w.writerow({k: ("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v) for k,v in row.items()})
            atomic_move(temp, self.root / name)
        return {s: sum(r['state']==s for r in rows) for s in sorted({r['state'] for r in rows})}


class TextOnly(HTMLParser):
    def __init__(self):
        super().__init__(); self.text=[]
    def handle_data(self, data):
        self.text.append(data)


def validate_word(path, original_filename, article_id, title, *, max_bytes=100_000_000, allow_html_doc=True):
    path = Path(path)
    size = path.stat().st_size
    if size < 32 or size > max_bytes:
        raise InvalidDownload("Export is empty, too small or exceeds max_download_bytes")
    ext = Path(original_filename.replace('\\','/')).suffix.lower()
    with path.open('rb') as f:
        head = f.read(4096)
    if ext == '.docx':
        try:
            with zipfile.ZipFile(path) as z:
                if not {'[Content_Types].xml','word/document.xml'} <= set(z.namelist()):
                    raise InvalidDownload("DOCX does not contain a Word document")
                if sum(i.file_size for i in z.infolist()) > max_bytes * 5:
                    raise InvalidDownload("DOCX expanded size exceeds validation limit")
                if z.testzip() is not None:
                    raise InvalidDownload("DOCX archive integrity check failed")
        except (zipfile.BadZipFile, RuntimeError) as exc:
            raise InvalidDownload("Export is not a readable DOCX file") from exc
        return ext, 'DOCX_CONTAINER_VALIDATED'
    if ext == '.doc' and head.startswith(bytes.fromhex('D0CF11E0A1B11AE1')):
        return ext, 'LEGACY_DOC_CONTAINER_SIGNATURE'
    if ext == '.rtf' and head.lstrip().startswith(b'{\\rtf'):
        return ext, 'RTF_SIGNATURE'
    if ext == '.doc' and allow_html_doc:
        data = path.read_bytes().decode('utf-8', errors='replace')
        if re.search(r'<(?:html|body)\b', data, re.I):
            if re.search(r'<input[^>]+type\s*=\s*[\"\x27]?password', data, re.I):
                raise InvalidDownload("Word export appears to contain a login form")
            parser=TextOnly();parser.feed(data)
            text=' '.join(' '.join(parser.text).casefold().split())
            norm_title=' '.join(title.casefold().split())
            if article_id.casefold() in text or (len(norm_title)>=6 and norm_title in text):
                return ext, 'WORD_HTML_WITH_ARTICLE_ID_OR_TITLE'
    raise InvalidDownload("Expected a Word DOCX, DOC or RTF export; received an unsupported or invalid file")
