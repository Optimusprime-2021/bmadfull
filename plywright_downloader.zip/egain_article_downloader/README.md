# eGain article downloader

Read article IDs from Excel, search Chase Answers, open the matching article and save its Word export. The script runs one article at a time, checkpoints each completed file and retries transient failures. Rerun the same command and output folder to resume.

This package follows the four screenshots you supplied. **The private eGain site was not accessed or tested live.** The search and Word selectors are configurable because screenshots do not expose the site's DOM. The supplied `sample_articles.xlsx` contains the 20 fully visible rows from your Excel screenshot, not your full article inventory. Replace it with your actual workbook for a complete run.

## 1. Install on your corporate computer

Use Python 3.10 or later and installed Chrome. Open PowerShell in the extracted `egain_article_downloader` folder:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

The default configuration uses installed Chrome. For Edge, change `browser_channel` in `config.json` to `"msedge"`. For bundled Chromium, use `null` and install its browser once:

```powershell
.\.venv\Scripts\python.exe -m playwright install chromium
```

The script uses a separate persistent browser profile in your output folder. Complete normal company SSO/MFA in that browser; no password is stored in this script. Your normal Chrome profile is not imported. Playwright documents browser session reuse in its [authentication guide](https://playwright.dev/python/docs/auth) and the dedicated profile option in [persistent contexts](https://playwright.dev/python/docs/api/class-browsertype#browser-type-launch-persistent-context).

## 2. Check the workbook

Expected headers are in row 1:

| Owning Area | Document Name | Article # |
|---|---|---|
| SCRA/MLA | SCRA Auto - Alfa | ID-45255 |
| SCRA/MLA | SCRA / MLA Card CIT Event report | ID-45257 |

Only `Article #` is required. `Document Name` helps select the correct search result. The ID on the opened article page is checked independently before export. Text IDs such as `ID-45255` and whole-number numeric IDs are accepted. Duplicates are downloaded once, with all source row numbers retained in the report. Formula IDs and invalid values are reported. The source workbook is never modified.

Validate the sample, then your full workbook:

```powershell
.\.venv\Scripts\python.exe download_articles.py plan --excel .\sample_articles.xlsx
.\.venv\Scripts\python.exe download_articles.py plan --excel "C:\KB\articles.xlsx"
```

Use `--sheet "Sheet1"` to select a worksheet. Otherwise, the active sheet is read. Different headers can be specified with `--id-column "Article ID" --title-column "Title" --header-row 2`. CSV and XLSM input are also supported; save legacy XLS as XLSX first. Hidden/filtered rows are included; provide a workbook containing only the inventory you intend to download.

## 3. Test one article

```powershell
.\.venv\Scripts\python.exe download_articles.py run --excel "C:\KB\articles.xlsx" --output "C:\KB\egain-output" --limit 1
```

1. The script opens the eGain home page in its browser.
2. Complete SSO/MFA normally. Wait until the KB search box is visible.
3. Press Enter in PowerShell.
4. The script enters the article ID, submits search, clicks the matching article link, verifies the article ID and clicks the Word icon.
5. Open the saved file in Word and confirm the export contains the expected article.

The observed base URL is preconfigured as `https://jpmc.egain.cloud/ccb/kb/ccbops-regops`. Internal content IDs are followed from search links; they are not invented from article numbers.

If the first run cannot locate the search field or Word icon, use the selector setup below. A failed ID remains in the checkpoint and is included in the next normal run.

## 4. Download the full list or resume

```powershell
.\.venv\Scripts\python.exe download_articles.py run --excel "C:\KB\articles.xlsx" --output "C:\KB\egain-output"
```

Use this exact command again after an interruption. Files marked successful are skipped only when their size and SHA-256 checksum still match. Deleted or changed files are queued again. Each incomplete article gets up to three attempts per invocation, with increasing delays. Later articles continue after ordinary failures. The run stops on detected expired authentication so you can sign in again.

Retry only previously failed IDs:

```powershell
.\.venv\Scripts\python.exe download_articles.py run --excel "C:\KB\articles.xlsx" --output "C:\KB\egain-output" --only-failed
```

`--only-failed` selects `FAILED` and `AUTH_REQUIRED` records. It does not select new or pending IDs. A normal run is the simplest way to finish the entire workbook.

Show checkpoint counts without opening a browser:

```powershell
.\.venv\Scripts\python.exe download_articles.py status --output "C:\KB\egain-output"
```

After an interactive run establishes a valid session, a later run can use `--non-interactive`. Add `--headless` only if your SSO and browser configuration support it. These options cannot perform an interactive sign-in; an expired session requires a headed run.

## Selector setup for the actual site

Inspect the homepage or an article without clicking Word export:

```powershell
.\.venv\Scripts\python.exe download_articles.py inspect --output "C:\KB\egain-output" --pause
.\.venv\Scripts\python.exe download_articles.py inspect --article-id ID-45255 --output "C:\KB\egain-output" --pause
```

After sign-in, the command saves `diagnostics/inspect.png` and `diagnostics/selector_candidates.json`. With `--pause`, Playwright Inspector lets you pick the actual element. If automatic article navigation fails, the command lets you navigate manually before inspecting it. Playwright's [locator guide](https://playwright.dev/python/docs/locators) explains accessible names and CSS selection.

Set relevant CSS selectors in `config.json`. The examples below are **illustrative**, not confirmed attributes from your site:

| Config field | What to target | Illustrative value |
|---|---|---|
| `search_input_css` | The article search input | `input[placeholder="Type your question here"]` |
| `search_submit_css` | Search button, if Enter does not submit | `button[aria-label="Search"]` |
| `result_link_css` | Article links on search results | `a[href*="/content/"]` |
| `result_item_css` | Each result card containing its ID and link | `.search-result` |
| `article_heading_css` | The article's title | `h1` |
| `article_id_css` | Exact article ID metadata below the title | `.article-metadata .article-id` |
| `word_export_css` | The clickable Word export control | `button[title="Export to Word"]` |
| `session_expired_css` | A visible session-expiry message | `.session-expired` |
| `frame_css` | An iframe containing KB controls, if present | `iframe#knowledge` |

The selectors must identify one visible target. Use a specific Word selector if the automatic match is ambiguous. Do not select the printer, PDF export, email or bookmark icon. If the Word logo is an image inside a clickable parent, target that parent when possible. Playwright Inspector may produce `get_by_role(...)`; for these config fields, use an equivalent CSS selector such as `[aria-label="Export to Word"]`.

Defaults try the observed search placeholder, accessible search fields and Word-specific labels/images. The fallback ID check reads metadata immediately after the title. Supplying the real `article_id_css` is preferable when the page contains other IDs nearby. The script refuses to export when it cannot uniquely verify the requested article ID.

`search_mode: "ui"` fills the search input and presses Enter. If this UI interaction is unsuitable, `"direct"` uses the observed `/search?q=ID-45255` route, then still clicks and verifies the result. An export confirmation dialog, a different route layout, shadow DOM or nested iframe layout may require a site-adapter change in `browser_flow.py`; these behaviors cannot be determined from screenshots alone.

## Files and checkpoints

Use a local output directory on the same computer. Keep its downloaded files and SQLite checkpoint together. SQLite WAL checkpoints and a shared browser profile are not intended for simultaneous runs on a network share.

| Path under the output folder | Purpose |
|---|---|
| `articles/ID-45255.docx` | Validated downloaded file; `.doc` or `.rtf` retained when that is the actual export |
| `checkpoint.sqlite3` | Article state, stage, attempts, checksum, source rows and provenance |
| `download_report.csv` | One row per unique valid ID in the current input |
| `failed_articles.csv` | All incomplete IDs in the current input, including pending IDs |
| `input_errors.csv` | Excel rows that could not be interpreted as article IDs |
| `staging/` | Temporary files; a completed staged download can be recovered after a crash |
| `diagnostics/` | Viewport screenshots of non-authentication failures and selector inspection output |
| `browser-profile/` | Local browser session used for normal SSO reuse |
| `run.lock` | OS-held lock that prevents two runs using the same folder |

States are `PENDING`, `IN_PROGRESS`, `STAGED`, `SUCCESS`, `FAILED` and `AUTH_REQUIRED`. These are operational download states, not article policy classifications. `STAGED` means a validated file and its hash have been recorded before the final rename. If the process stops during that rename/commit sequence, the next run checks the journal and completes the save without a new download when possible.

Reports contain the verified article URL without query parameters, article metadata, attempt counts and a SHA-256 checksum. The database additionally retains the displayed title and original export filename. Reports are refreshed on normal completion or a handled interruption; after a hard power loss they are refreshed by the next run. Keep the SQLite database as the checkpoint authority.

The browser profile contains session material, and diagnostics may contain article text. Keep the output folder in your approved local location; share only the scripts when distributing this package.

This is a batch snapshot downloader. A successful ID is not periodically checked for a newly published revision. To collect a new snapshot of every article, use a new output directory and sign in there. The script downloads the Word representation offered by the article toolbar. It does not separately download every linked attachment, image resource or historical article revision.

## Download validation and retry behavior

The script registers download listeners before clicking Word and saves the file before closing its browser context, following Playwright's [download lifecycle](https://playwright.dev/python/docs/downloads). Same-tab downloads and downloads from export tabs are handled.

| Condition | Behavior |
|---|---|
| Duplicate Excel ID | One download; record every input row |
| Temporary timeout/server error | Retry with increasing delay, up to `max_attempts` per invocation |
| No search result | Retry, then record failure and continue |
| Wrong/ambiguous article ID | Record failure without clicking Word; continue |
| Missing/ambiguous control | Record selector failure; configure the selector before rerunning |
| SSO required | Stop run and preserve completed files |
| DOCX export | Verify Word package entries and ZIP CRCs |
| Legacy DOC/RTF | Check the corresponding file signature |
| HTML-based `.doc` export | Require article ID or displayed title and reject password forms |
| Empty, oversized or unsupported file | Reject and retry |
| Disk/SQLite commit failure | Stop; preserve journal for recovery |
| Successful file missing or changed | Requeue on next normal run |

These checks establish page identity and file/container integrity. They do not prove that every paragraph or externally linked image was included by eGain's export implementation. Inspect the first Word file before running the full inventory.

`max_download_bytes` is checked after the browser saves the download. It does not enforce a streaming network-transfer limit. Defaults are three attempts, a two-second initial retry delay, 1.5 seconds between articles and a 100 MB validation limit.

Exit codes: `0` = selected articles completed; `2` = incomplete selected articles or invalid input rows; `3` = sign-in required; `1` = setup/local failure; `130` = Ctrl+C. With `--limit`, success refers to that limited selection. Review the report for pending IDs in the full inventory.

## Implementation and tests

| File | Responsibility |
|---|---|
| `download_articles.py` | Commands, serial processing, retry policy and exit codes |
| `browser_flow.py` | SSO handoff, search, result selection, identity check and Word export |
| `core.py` | Excel/CSV input, file lock, SQLite checkpoints and file validation |
| `config.json` | Browser/site configuration and optional selector overrides |
| `tests/test_downloader.py` | Offline file, checkpoint, selection and retry tests |

Run the offline tests:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The delivered version passed 31 offline tests covering input parsing, duplicate handling, result selection, file validation, interrupted saves before and after rename, checksum-based resume, retries, authentication-stop behavior and continuation after article failures. Browser interactions are replaced by a fake browser in the orchestration tests. Live eGain selectors, corporate SSO, Windows browser launch and actual Word export remain to be verified on your computer with the one-article run.
