"""Site adapter. Screenshot-based defaults must be verified on the real site."""
from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote, urljoin, urlsplit, urlunsplit

from core import (AccessBlocked, ArticleNotFound, AuthenticationRequired,
                  ConfigurationError, DownloadError, IdentityError, SelectorError)


def origin(url):
    p = urlsplit(url)
    return p.scheme.lower(), p.netloc.lower()


def clean_url(url):
    p = urlsplit(url)
    return urlunsplit((p.scheme, p.netloc, p.path, "", ""))


def normalized_text(text):
    return " ".join(text.casefold().split())


def ids_in(text):
    return {"ID-" + n for n in re.findall(r"\bID\s*[-–—]\s*(\d+)\b", text, re.I)}


def choose_result(candidates, article, base_url):
    """Choose one distinct same-site article URL; page metadata is checked later."""
    valid = {}
    prefix = urlsplit(base_url).path.rstrip("/") + "/content/"
    for item in candidates:
        url = urljoin(base_url + "/", item["href"])
        if origin(url) != origin(base_url) or not urlsplit(url).path.startswith(prefix):
            continue
        # Duplicate links to the same article (for example title and thumbnail) are one candidate.
        key = clean_url(url)
        entry = valid.setdefault(key, {"url": url, "texts": [], "ids": set()})
        entry["texts"].append(normalized_text(item.get("text", "")))
        entry["ids"].update(ids_in(item.get("card_text", "")))
    values = list(valid.values())
    by_id = [v for v in values if v["ids"] == {article.article_id}]
    if len(by_id) == 1:
        return by_id[0]["url"]
    if len(by_id) > 1:
        raise IdentityError("More than one article URL has the requested ID; inspect search results")
    by_title = [v for v in values if article.title and normalized_text(article.title) in v["texts"]]
    if len(by_title) == 1:
        return by_title[0]["url"]
    if len(values) == 1:
        return values[0]["url"]
    if values:
        raise IdentityError("Search results are ambiguous; no unique ID or exact title match")
    return None


@dataclass
class Export:
    temp_path: Path
    filename: str
    title: str
    url: str


class BrowserFlow:
    def __init__(self, config, output, *, headless=False, interactive=True):
        self.config, self.output = config, Path(output)
        self.headless, self.interactive = headless, interactive
        self.selectors = config["selectors"]
        self.context = self.page = self.playwright = None
        self.last_page = None

    async def __aenter__(self):
        try:
            from playwright.async_api import async_playwright
        except ImportError as exc:
            raise ConfigurationError("Install requirements.txt before running the browser") from exc
        self.playwright = await async_playwright().start()
        try:
            self.context = await self.playwright.chromium.launch_persistent_context(
                str(self.output / "browser-profile"),
                channel=self.config["browser_channel"],
                headless=self.headless, accept_downloads=True,
                viewport={"width": 1440, "height": 1000},
            )
            self.context.set_default_timeout(self.config["element_timeout_ms"])
            self.context.set_default_navigation_timeout(self.config["navigation_timeout_ms"])
            self.page = self.context.pages[0] if self.context.pages else await self.context.new_page()
            self.last_page = self.page
            return self
        except Exception as exc:
            await self.playwright.stop()
            raise ConfigurationError(
                "Could not start the browser. Check browser_channel and installation; "
                "close another run using this output/profile."
            ) from exc

    async def __aexit__(self, *_):
        try:
            if self.context:
                await self.context.close()
        finally:
            if self.playwright:
                await self.playwright.stop()

    def scope(self, page):
        frame = self.selectors["frame_css"]
        return page.frame_locator(frame) if frame else page

    async def check_auth(self, page):
        if page.is_closed():
            raise DownloadError("Browser tab closed before the article was completed")
        if page.url != "about:blank" and origin(page.url) != origin(self.config["base_url"]):
            raise AuthenticationRequired("SSO sign-in is required; rerun in headed interactive mode")
        selector = self.selectors["session_expired_css"]
        if selector and await self.scope(page).locator(selector).is_visible():
            raise AuthenticationRequired("The configured session-expired element is visible")
        # Do not enter credentials, handle MFA, or attempt to bypass a sign-in page.
        fields = page.locator('input[type="password"]:visible')
        if await fields.count():
            raise AuthenticationRequired("Sign-in page detected; rerun in headed interactive mode")

    async def navigate(self, url, *, allow_login=False):
        response = await self.page.goto(url, wait_until="domcontentloaded")
        if response:
            if response.status == 401 and not allow_login:
                raise AuthenticationRequired("Server requires sign-in")
            if response.status == 403:
                raise AccessBlocked("Server denied access; no access-control bypass is attempted")
            if response.status == 429 or response.status >= 500:
                raise DownloadError(f"Server returned HTTP {response.status}; retry later")
        if not allow_login:
            await self.check_auth(self.page)

    async def login(self, *, validate_search=True):
        await self.navigate(self.config["base_url"] + "/home", allow_login=self.interactive)
        if self.interactive:
            print("\nIn the opened browser, complete normal SSO/MFA and return to the KB home page.")
            print("This program does not collect your password.")
            await asyncio.to_thread(input, "When the KB search box is visible, press Enter here: ")
            # User may have completed SSO in another tab.
            candidates = [p for p in self.context.pages
                          if not p.is_closed() and p.url.startswith(self.config["base_url"])]
            if candidates:
                self.page = candidates[-1]
            await self.check_auth(self.page)
            await self.navigate(self.config["base_url"] + "/home")
        await self.check_auth(self.page)
        self.last_page = self.page
        # Ensures authentication really returned to a usable KB page.
        if validate_search:
            await self.search_input(self.page)

    async def unique_visible(self, locator, description):
        visible = []
        for i in range(await locator.count()):
            item = locator.nth(i)
            if await item.is_visible():
                visible.append(item)
        if len(visible) > 1:
            raise SelectorError(f"Multiple visible {description}; set a more specific CSS selector")
        return visible[0] if visible else None

    async def search_input(self, page):
        scope = self.scope(page)
        custom = self.selectors["search_input_css"]
        locators = ([scope.locator(custom)] if custom else [
            scope.get_by_placeholder("Type your question here", exact=True),
            scope.get_by_role("searchbox"),
            scope.locator('input[type="search"]'),
            scope.get_by_role("combobox"),
        ])
        until = time.monotonic() + self.config["element_timeout_ms"] / 1000
        while time.monotonic() < until:
            await self.check_auth(page)
            for locator in locators:
                found = await self.unique_visible(locator, "search inputs")
                if found:
                    return found
            await asyncio.sleep(0.3)
        raise SelectorError("Search input not found. Use inspect and set search_input_css")

    async def result_candidates(self, page):
        links = self.scope(page).locator(self.selectors["result_link_css"])
        return await links.evaluate_all("""(links, cardSelector) => links
          .filter(a => a.getClientRects().length && getComputedStyle(a).visibility !== 'hidden')
          .map(a => {
            let card = cardSelector ? a.closest(cardSelector) : null;
            if (!card) {
              for (let p = a.parentElement; p; p = p.parentElement) {
                const urls = new Set([...p.querySelectorAll('a[href*="/content/"]')]
                  .map(x => x.href.split('?')[0]));
                if (urls.size > 1) break;
                if (/\\bID\\s*[-–—]\\s*\\d+/i.test(p.innerText || '')) { card=p; break; }
              }
            }
            return {href:a.href, text:a.innerText || a.getAttribute('aria-label') || '',
                    card_text:(card?.innerText || '').slice(0,12000)};
          })""", self.selectors["result_item_css"])

    async def search(self, article):
        await self.navigate(self.config["base_url"] + "/home")
        if self.config["search_mode"] == "direct":
            await self.navigate(self.config["base_url"] + "/search?q=" + quote(article.article_id))
        else:
            field = await self.search_input(self.page)
            await field.fill(article.article_id)
            custom = self.selectors["search_submit_css"]
            if custom:
                submit = await self.unique_visible(self.scope(self.page).locator(custom), "search submit buttons")
                if not submit:
                    raise SelectorError("Configured search submit button was not found")
                await submit.click()
            else:
                await field.press("Enter")
        until = time.monotonic() + self.config["element_timeout_ms"] / 1000
        while time.monotonic() < until:
            await self.check_auth(self.page)
            # Search suggestions are not the search results page.
            if "/search" in urlsplit(self.page.url).path:
                candidates = await self.result_candidates(self.page)
                url = choose_result(candidates, article, self.config["base_url"])
                if url:
                    return url
                no_results = self.scope(self.page).get_by_text(re.compile(r"^(?:No results found|0 results found)$", re.I))
                if await no_results.count() and await no_results.first.is_visible():
                    raise ArticleNotFound("No search results for this article ID")
            await asyncio.sleep(0.4)
        raise ArticleNotFound("No usable article result before timeout; verify ID, access and result selectors")

    async def metadata(self, page):
        scope = self.scope(page)
        heading = await self.unique_visible(scope.locator(self.selectors["article_heading_css"]), "article headings")
        if not heading:
            return None
        title = (await heading.inner_text()).strip()
        custom = self.selectors["article_id_css"]
        if custom:
            element = await self.unique_visible(scope.locator(custom), "article metadata IDs")
            text = await element.inner_text() if element else ""
        else:
            # Read the metadata AFTER h1, not the query string or search field.
            text = await heading.evaluate("""h => {
              for (let p=h.parentElement; p; p=p.parentElement) {
                const r=document.createRange(); r.setStartAfter(h); r.setEnd(p,p.childNodes.length);
                const s=r.cloneContents().textContent.slice(0,700);
                if (/\\bID\\s*[-–—]\\s*\\d+/i.test(s)) return s;
              }
              return '';
            }""")
        return title, ids_in(text)

    async def open_article(self, url, article):
        links = self.scope(self.page).locator(self.selectors["result_link_css"])
        matching = []
        for i in range(await links.count()):
            link = links.nth(i)
            href = await link.get_attribute("href")
            if href and urljoin(self.page.url, href) == url and await link.is_visible():
                matching.append(link)
        if not matching:
            raise DownloadError("Chosen search result changed before it could be opened")
        # All these links have the identical verified candidate URL.
        before = set(self.context.pages)
        await matching[0].click()
        until = time.monotonic() + self.config["navigation_timeout_ms"] / 1000
        while time.monotonic() < until:
            pages = [p for p in self.context.pages if p not in before] + [self.page]
            for page in pages:
                if page.is_closed() or page.url == "about:blank":
                    continue
                await self.check_auth(page)
                if "/content/" not in urlsplit(page.url).path:
                    continue
                self.last_page = page
                metadata = await self.metadata(page)
                if not metadata or not metadata[1]:
                    continue
                title, found_ids = metadata
                if found_ids != {article.article_id}:
                    raise IdentityError("Article metadata ID does not uniquely match the requested ID; no export clicked")
                return page, title
            await asyncio.sleep(0.3)
        raise IdentityError("Could not verify article ID near its heading; configure article_id_css")

    async def word_button(self, page):
        scope = self.scope(page)
        custom = self.selectors["word_export_css"]
        name = re.compile(r"\b(?:word|docx?)\b", re.I)
        locators = [scope.locator(custom)] if custom else [
            scope.get_by_role("button", name=name).or_(scope.get_by_role("link", name=name)),
            scope.locator('[title*="word" i], [aria-label*="word" i]'),
            scope.locator('button:has(img[alt*="word" i]), a:has(img[alt*="word" i]), '
                          'button:has(img[src*="word" i]), a:has(img[src*="word" i])'),
            scope.locator('img[alt*="word" i], img[src*="word" i]'),
        ]
        until = time.monotonic() + self.config["element_timeout_ms"] / 1000
        while time.monotonic() < until:
            await self.check_auth(page)
            for locator in locators:
                found = await self.unique_visible(locator, "Word export controls")
                if found:
                    return found
            await asyncio.sleep(0.3)
        raise SelectorError("Word export icon not found. Use inspect and set word_export_css")

    async def export_word(self, page, title, article):
        button = await self.word_button(page)
        # Recheck after the toolbar appears, so SPA transitions cannot leave us
        # trusting metadata left over from the previous page.
        await self.check_auth(page)
        metadata = await self.metadata(page)
        if not metadata or metadata[1] != {article.article_id}:
            raise IdentityError("Article ID changed or could not be verified before Word export")
        title = metadata[0]
        article_url = clean_url(page.url)
        queue = asyncio.Queue()
        attached = []
        def attach(p):
            if p not in attached:
                p.on("download", queue.put_nowait)
                attached.append(p)
        attach(page)
        self.context.on("page", attach)
        temp = self.output / "staging" / f"{article.article_id}.{uuid.uuid4().hex}.part"
        temp.parent.mkdir(parents=True, exist_ok=True)
        try:
            # Register listeners BEFORE clicking. New export tabs are handled too.
            await button.click()
            until = time.monotonic() + self.config["download_timeout_ms"] / 1000
            download = None
            while time.monotonic() < until:
                try:
                    download = await asyncio.wait_for(queue.get(), timeout=min(1, max(.01, until-time.monotonic())))
                    break
                except asyncio.TimeoutError:
                    for active in attached:
                        if not active.is_closed() and active.url != "about:blank":
                            # Export hosts can differ; only test the original article for SSO redirects.
                            if active == page:
                                await self.check_auth(active)
            if download is None:
                raise DownloadError("No download event after Word click; check export permission, icon or confirmation dialog")
            await asyncio.wait_for(download.save_as(str(temp)), self.config["download_timeout_ms"] / 1000)
            return Export(temp, download.suggested_filename, title, article_url)
        except BaseException:
            if temp.exists():
                temp.unlink()
            raise
        finally:
            self.context.remove_listener("page", attach)
            for active in attached:
                active.remove_listener("download", queue.put_nowait)

    async def download(self, article, stage):
        self.last_page = self.page
        stage("SEARCH")
        url = await self.search(article)
        stage("VERIFY_ARTICLE")
        page, title = await self.open_article(url, article)
        stage("WORD_EXPORT")
        return await self.export_word(page, title, article)

    async def diagnostic(self, article_id, attempt):
        page = self.last_page
        if not page or page.is_closed():
            return
        try:
            await self.check_auth(page)
            folder = self.output / "diagnostics"
            folder.mkdir(parents=True, exist_ok=True)
            await page.screenshot(path=str(folder / f"{article_id}.attempt-{attempt}.png"), full_page=False, timeout=5000)
        except Exception:
            pass  # Diagnostics must not obscure the original failure.

    async def reset(self):
        for p in list(self.context.pages):
            if p != self.page and not p.is_closed():
                await p.close()
        if self.page.is_closed():
            self.page = await self.context.new_page()
        self.last_page = self.page

    async def inspect(self, article_id, *, pause=False):
        from core import Article
        page = self.page
        if article_id:
            try:
                url = await self.search(Article(article_id))
                page, _ = await self.open_article(url, Article(article_id))
            except DownloadError as exc:
                print(f"Automatic navigation stopped: {exc}")
                if not self.interactive:
                    raise
                print("Navigate manually to the article tab, then press Enter.")
                await asyncio.to_thread(input, "Continue: ")
                candidates = [p for p in self.context.pages if "/content/" in urlsplit(p.url).path]
                page = candidates[-1] if candidates else self.page
        await self.check_auth(page)
        folder = self.output / "diagnostics"
        folder.mkdir(parents=True, exist_ok=True)
        info = await self.scope(page).locator('input, button, a, [role="button"], img, h1').evaluate_all("""els => els
          .filter(e => e.getClientRects().length).slice(0,250).map(e => ({
            tag:e.tagName, id:e.id, class:e.className?.baseVal ?? e.className,
            role:e.getAttribute('role'), title:e.getAttribute('title'),
            ariaLabel:e.getAttribute('aria-label'), placeholder:e.getAttribute('placeholder'),
            alt:e.getAttribute('alt'), text:(e.innerText || '').slice(0,120),
            href:e.href ? new URL(e.href,location.href).pathname : null,
            src:e.tagName==='IMG' && e.src ? new URL(e.src,location.href).pathname : null
          }))""")
        (folder / "selector_candidates.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
        await page.screenshot(path=str(folder / "inspect.png"), full_page=False)
        print(f"Saved selector candidates and screenshot to {folder}")
        if pause:
            print("Playwright Inspector is open. Use Pick locator; resume to finish.")
            await page.pause()
